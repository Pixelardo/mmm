<?php
include("con_db.php");

if (isset($_POST['registrar_venta'])) {
    $ID_Vendedor = mysqli_real_escape_string($conex, $_POST['ID_Vendedor']);
    $ISBN = mysqli_real_escape_string($conex, $_POST['ISBN']);
    $Fecha_Venta = mysqli_real_escape_string($conex, $_POST['Fecha_Venta']);
    $Cantidad = mysqli_real_escape_string($conex, $_POST['Cantidad']);
    $Precio_Unitario = mysqli_real_escape_string($conex, $_POST['Precio_Unitario']);

    // Verificar si la cantidad y el precio unitario son números válidos
    if (!is_numeric($Cantidad) || !is_numeric($Precio_Unitario)) {
        echo "<script>alert('La cantidad y el precio deben ser números válidos');</script>";
        exit; // Detener la ejecución del script si los valores no son válidos
    }

    $Total = $Cantidad * $Precio_Unitario;

    // Verificar si el ISBN existe en la tabla libros
    $consulta_libro = "SELECT * FROM libros WHERE ISBN = '$ISBN'";
    $resultado_libro = mysqli_query($conex, $consulta_libro);
    if (mysqli_num_rows($resultado_libro) > 0) {
        // El ISBN existe, podemos proceder con la inserción
        $consulta_venta = "INSERT INTO ventas (ID_Vendedor, ISBN, Fecha_Venta, Cantidad, Precio_Unitario, Total) 
                           VALUES ('$ID_Vendedor', '$ISBN', '$Fecha_Venta', '$Cantidad', '$Precio_Unitario', '$Total')";
        if (mysqli_query($conex, $consulta_venta)) {
            echo "<script>alert('Venta registrada correctamente');</script>";
        } else {
            echo "<script>alert('Error al registrar la venta: " . mysqli_error($conex) . "');</script>";
        }
    } else {
        echo "<script>alert('El ISBN ingresado no existe en la base de datos');</script>";
    }
}
?>

<?php
session_start(); // Iniciar sesión si no se ha iniciado

// Verificar si el administrador ha iniciado sesión
if (!isset($_SESSION['id_administrador'])) {
    // Si el administrador no ha iniciado sesión, redirigir al inicio de sesión del administrador
    header("Location: login_administrador.php");
    exit();
}

// Incluir archivo de conexión a la base de datos
include("con_db.php");

// Variable para verificar si se creó la cuenta
$cuenta_creada = false;

// Verificar si se enviaron los datos del formulario
if(isset($_POST['nombre'], $_POST['email'], $_POST['telefono'], $_POST['contraseña'])) {
    // Obtener el ID del administrador autenticado desde la sesión
    $id_administrador = $_SESSION['id_administrador'];

    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $contraseña = $_POST['contraseña'];

    // Insertar la cuenta del vendedor en la base de datos
    $consulta = "INSERT INTO vendedores (Nombre, Email, Contraseña, Telefono, Fecha_Alta, ID_Administrador) 
                 VALUES ('$nombre', '$email', '$contraseña', '$telefono', CURRENT_DATE(), '$id_administrador')";
    $resultado = mysqli_query($conex, $consulta);

    if($resultado) {
        $cuenta_creada = true;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="css/estilo.css">
    <title>Crear Cuenta de Vendedor</title>
</head>
<body>
    <h1>Crear Cuenta de Vendedor</h1>
    
    <?php if ($cuenta_creada): ?>
        <p>Cuenta de vendedor creada exitosamente.</p>
    <?php else: ?>
        <!-- Formulario para crear la cuenta del vendedor -->
        <form method="post" action="">
            <label for="nombre">Nombre:</label><br>
            <input type="text" id="nombre" name="nombre" required><br><br>
            
            <label for="email">Correo electrónico:</label><br>
            <input type="email" id="email" name="email" required><br><br>
            
            <label for="telefono">Teléfono:</label><br>
            <input type="text" id="telefono" name="telefono" required><br><br>
            
            <label for="contraseña">Contraseña:</label><br>
            <input type="password" id="contraseña" name="contraseña" required><br><br>
            
            <input type="submit" value="Crear Cuenta">
        </form>
    <?php endif; ?>
</body>
</html>


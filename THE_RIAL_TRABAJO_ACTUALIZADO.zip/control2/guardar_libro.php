<?php
// Incluir el archivo de conexión a la base de datos
include("con_db.php");

// Recibir datos del formulario
$identificador = $_POST['identificador'];
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];
$fecha_alta = $_POST['fecha_alta'];
$genero = $_POST['genero'];
$precio = $_POST['precio'];
$formato = $_POST['formato'];
$autor = $_POST['autor'];
$idioma = $_POST['idioma'];
$disponibilidad = $_POST['disponibilidad'];

// Obtener el ID del vendedor desde la sesión
session_start();
$id_vendedor = $_SESSION['id_vendedor'];

// Verificar si el ISBN ya existe en la base de datos
$query_check_isbn = "SELECT * FROM libros WHERE ISBN = '$identificador'";
$result_check_isbn = mysqli_query($conex, $query_check_isbn);

if(mysqli_num_rows($result_check_isbn) > 0) {
    echo "Error: El ISBN ya existe en la base de datos.";
} else {
    // Preparar la consulta SQL para insertar un libro
    $query = "INSERT INTO libros (ISBN, Titulo, Descripcion, Fecha_Alta, Genero, Precio, Formato, Autor, Idioma, Disponibilidad, ID_Vendedor) 
              VALUES ('$identificador', '$titulo', '$descripcion', '$fecha_alta', '$genero', '$precio', '$formato', '$autor', '$idioma', '$disponibilidad', '$id_vendedor')";

    // Ejecutar la consulta SQL
    if(mysqli_query($conex, $query)) {
        echo "Libro ingresado correctamente.";
    } else {
        echo "Error al ingresar el libro: " . mysqli_error($conex);
    }
}

// Cerrar la conexión a la base de datos
mysqli_close($conex);
?>

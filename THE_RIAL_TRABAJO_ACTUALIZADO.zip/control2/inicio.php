<!DOCTYPE html>
<html>
<head>
    <title>Registrar usuario</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <h1>Registro</h1>
    <form method="post" action="">
        <h2>Crear cuenta</h2>
        <input type="text" id="username" name="username" placeholder="Nombre de usuario" required>
        <input type="text" id="name" name="name" placeholder="Nombre completo" required>
        <input type="email" id="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" id="password" name="password" placeholder="Contraseña" required>
        <label for="intereses">Intereses:</label>
        <label for="intereses">Intereses:</label>
<select id="intereses" name="intereses[]" multiple required>
    <option value="Historia Y Geografía">Historia Y Geografía</option>
    <option value="Infantil">Infantil</option>
    <option value="Fantasía">Fantasía</option>
</select><br><br>
        <input type="submit" name="register" value="Registrarse">
    </form>
    
    <h2>Iniciar sesión</h2>
    <form method="post" action="">
        <input type="text" name="username" placeholder="Nombre de usuario">
        <input type="password" name="password" placeholder="Contraseña">
        <input type="submit" name="login" value="Iniciar sesión">
    </form>
    
    <?php 
    include("con_db.php");
    
    if (isset($_POST['register'])) {
        if(strlen($_POST['username']) >= 1 && strlen($_POST['name']) >= 1 && strlen($_POST['password']) >= 1 && strlen($_POST['email']) >= 1 && isset($_POST['intereses'])) {
            $username = trim($_POST['username']);
            $name = trim($_POST['name']);
            $password = trim($_POST['password']);
            $email = trim($_POST['email']);
            $intereses = implode(", ", $_POST['intereses']); // Convertir el array de intereses en una cadena

            $fecha_creacion = "NOW()";

            $consulta_existencia = "SELECT * FROM usuarios WHERE nombre_usuario = '$username'";
            $resultado_existencia = mysqli_query($conex, $consulta_existencia);

            if (mysqli_num_rows($resultado_existencia) == 0) {
                $consulta = "INSERT INTO usuarios(nombre_usuario, nombre, contraseña, email, intereses, fecha_creacion) VALUES ('$username', '$name', '$password', '$email', '$intereses', $fecha_creacion)";
                $resultado = mysqli_query($conex, $consulta);

                if ($resultado) {
                    ?>
                    <h3 class="ok">¡Te has inscripto correctamente!</h3>
                    <?php
                } else {
                    ?>
                    <h3 class="bad">¡Ups ha ocurrido un error!</h3>
                    <?php
                }
            } else {
                ?>
                <h3 class="bad">¡El nombre de usuario ya existe!</h3>
                <?php
            }
        } else {
            ?>
            <h3 class="bad">¡Por favor complete todos los campos y seleccione al menos un interés!</h3>
            <?php
        }
    }

    session_start();

    if(isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $consulta = "SELECT * FROM usuarios WHERE nombre_usuario='$username' AND contraseña='$password'";
        $resultado = mysqli_query($conex, $consulta);

        if(mysqli_num_rows($resultado) > 0) {
            $_SESSION['username'] = $username;
            header("Location: menu.php");
            exit();
        } else {
            echo "Nombre de usuario o contraseña incorrectos";
        }
    }
    ?>
</body>
</html>

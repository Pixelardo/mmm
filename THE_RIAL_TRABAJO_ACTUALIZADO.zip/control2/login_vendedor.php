<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Iniciar Sesión - Vendedor</title>
</head>
<body>
    <h1>Iniciar Sesión - Vendedor</h1>
    
    <!-- Formulario de inicio de sesión para vendedores -->
    <form method="post" action="">
        <label for="correo">Correo electrónico:</label><br>
        <input type="email" id="correo" name="correo" required><br><br>
        
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        
        <input type="submit" value="Iniciar Sesión">
    </form>

    <?php
    session_start(); // Iniciar sesión

    if(isset($_POST['correo'], $_POST['contraseña'])) {
        // Obtener las credenciales del formulario
        $correo = $_POST['correo'];
        $contraseña = $_POST['contraseña'];

        // Aquí debes realizar la validación de las credenciales en tu base de datos
        // Por ejemplo, una consulta SQL para verificar si el correo y la contraseña coinciden
        // Suponiendo que tienes una tabla 'vendedores' con campos 'Email' y 'Contraseña'
        // y que la conexión a la base de datos está configurada en 'con_db.php'
        include("con_db.php");
        $consulta = "SELECT ID_Vendedor FROM vendedores WHERE Email='$correo' AND Contraseña='$contraseña'";
        $resultado = mysqli_query($conex, $consulta);

        // Verificar si se encontró un vendedor con las credenciales proporcionadas
        if(mysqli_num_rows($resultado) == 1) {
            // Iniciar sesión y redirigir al vendedor a la página del vendedor
            $fila = mysqli_fetch_assoc($resultado);
            $_SESSION['id_vendedor'] = $fila['ID_Vendedor'];
            header("Location: pagina_vendedor.php");
            exit();
        } else {
            // Si las credenciales no son válidas, mostrar un mensaje de error y redirigir de nuevo a la página de inicio de sesión
            echo "Correo electrónico o contraseña incorrectos. Intente de nuevo.";
            header("refresh:3;url=login_vendedor.php"); // Redirigir después de 3 segundos
            exit();
        }
    }
    ?>
</body>
</html>

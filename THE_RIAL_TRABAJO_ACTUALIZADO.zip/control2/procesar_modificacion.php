<?php
// Verificar si se ha enviado el formulario
if(isset($_POST['submit'])) {
    // Obtener los datos del formulario
    $id_vendedor = $_POST['id_vendedor'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];
    $telefono = $_POST['telefono'];

    // Realizar la actualización en la base de datos
    include("con_db.php");
    $consulta = "UPDATE vendedores SET Nombre='$nombre', Email='$correo', Contraseña='$contraseña', Telefono='$telefono' WHERE ID_Vendedor='$id_vendedor'";
    if(mysqli_query($conex, $consulta)) {
        echo "Los datos del vendedor se han actualizado correctamente.";
    } else {
        echo "Error al actualizar los datos del vendedor: " . mysqli_error($conex);
    }
}
?>

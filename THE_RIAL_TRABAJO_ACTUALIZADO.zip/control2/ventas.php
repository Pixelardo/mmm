<?php
include("con_db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['registrar_venta'])) {
        $ID_Vendedor = $_POST['ID_Vendedor'];
        $ISBN = $_POST['ISBN'];
        $Fecha_Venta = $_POST['Fecha_Venta'];
        $Cantidad = $_POST['Cantidad'];
        $Precio_Unitario_Dolares = $_POST['Precio_Unitario'];
        
        // Supongamos que la tasa de conversión es 800 pesos chilenos por dólar
        $Tasa_Conversion = 800;
        $Precio_Unitario_CLP = $Precio_Unitario_Dolares * $Tasa_Conversion;
        $Total = $Cantidad * $Precio_Unitario_CLP;

        // Verificar si el ISBN existe en la tabla libros
        $consulta_libro = "SELECT * FROM libros WHERE ISBN = '$ISBN'";
        $resultado_libro = mysqli_query($conex, $consulta_libro);
        if (mysqli_num_rows($resultado_libro) > 0) {
            // El ISBN existe, podemos proceder con la inserción
            $consulta_venta = "INSERT INTO ventas (ID_Vendedor, ISBN, Fecha_Venta, Cantidad, Precio_Unitario, Total) 
                               VALUES ('$ID_Vendedor', '$ISBN', '$Fecha_Venta', '$Cantidad', '$Precio_Unitario_CLP', '$Total')";
            if (mysqli_query($conex, $consulta_venta)) {
                echo "<script>alert('Venta registrada correctamente');</script>";
            } else {
                echo "<script>alert('Error al registrar la venta: " . mysqli_error($conex) . "');</script>";
            }
        } else {
            echo "<script>alert('El ISBN ingresado no existe en la base de datos');</script>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="number"],
        input[type="date"],
        input[type="submit"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar Venta</h1>
        <form method="POST" action="ventas.php">
            <label for="ID_Vendedor">ID Vendedor:</label>
            <input type="text" id="ID_Vendedor" name="ID_Vendedor" required>

            <label for="ISBN">ISBN:</label>
            <input type="text" id="ISBN" name="ISBN" required>

            <label for="Fecha_Venta">Fecha de Venta:</label>
            <input type="date" id="Fecha_Venta" name="Fecha_Venta" required>

            <label for="Cantidad">Cantidad:</label>
            <input type="number" id="Cantidad" name="Cantidad" required>

            <label for="Precio_Unitario">Precio Unitario:</label>
            <input type="number" id="Precio_Unitario" name="Precio_Unitario" required>

            <input type="submit" name="registrar_venta" value="Registrar Venta">
        </form>
    </div>
</body>
</html>

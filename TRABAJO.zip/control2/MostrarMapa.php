<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/esilo.css">
    <title>Mostrar Mapa</title>
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            font-family: century gothic;
            text-align: center;
        }

        .topnav {
            overflow: hidden;
            background-color: #333;
        }

        .topnav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .topnav ul li {
            float: left;
        }

        .topnav ul li a {
            display: block;
            color: #fff;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .topnav ul li a:hover {
            background-color: #555;
        }

        /* Estilos para el contenedor de la tabla */
        #tabla-container {
            width: 80%; /* Ancho de la tabla */
            margin: 50px auto 0 auto; /* Centrar horizontalmente y agregar margen superior */
            text-align: center; /* Centrar contenido de la tabla */
        }

        /* Estilos para la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Estilos para el buscador */
        #searchInput {
            width: 50%;
            padding: 12px;
            margin: 10px auto; /* Centro verticalmente */
            display: block;
            box-sizing: border-box;
        }
        /* Agregamos estilos para las flechas de filtrado */
        .filter-arrow {
            cursor: pointer;
        }

        img {
            width: 100%; /* Reducir el ancho al 50% del tamaño original */
            height: auto; /* Mantener la proporción de aspecto */
            margin: 0 auto; /* Centrar la imagen horizontalmente */
            display: block; /* Evitar que la imagen cause espacios adicionales */
            max-width: 100%; /* Evitar que la imagen se desborde del contenedor */
        }
    </style>
</head>
<body>
    <div class="topnav">
        <ul>
            <li><a href="menu.php">Inicio</a></li>
            <li><a href="buscar_usuario.php">Mostrar Tabla</a></li>
            <li><a href="#">Mapa Conceptual</a></li>
            <li><a href="inicio.php">Cerrar Sesión</a></li>
        </ul>
    </div>

    <img src="Mapa_Conceptual.png" />

</body>
</html>
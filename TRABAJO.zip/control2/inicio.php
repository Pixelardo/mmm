<!DOCTYPE html>
<html>
    
<head>
    <title>Registrar usuario</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="css/estilo.css">

    

</head>


<body>

    
    <h1>Registro</h1>
    <form method="post" action="usuarios.php" onsubmit="return validateForm()">
        <h2>Crear cuenta</h2>
        <input type="text" id="username" name="username" placeholder="Nombre de usuario" required>
        <input type="text" id="name" name="name" placeholder="Nombre completo" required>
        <input type="email" id="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" id="password" name="password" placeholder="Contraseña" required>
        <input type="submit" name="register" value="Registrarse">
    </form>


    

    

    
    <h2>Iniciar sesión</h2>
    <form method="post" action="login.php">
        <input type="text" name="username" placeholder="Nombre de usuario">
        <input type="password" name="password" placeholder="Contraseña">
        <input type="submit" name="login" value="Iniciar sesión">

    </form>
    
    <?php 
        include("usuarios.php");
        ?>

</body>
</html>

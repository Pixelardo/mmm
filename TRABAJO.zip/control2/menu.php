<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barra de opciones</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            font-family: century gothic;
            text-align: center;
        }

        .topnav {
            overflow: hidden;
            background-color: #333;
        }

        .topnav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .topnav ul li {
            float: left;
        }

        .topnav ul li a {
            display: block;
            color: #fff;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .topnav ul li a:hover {
            background-color: #555;
        }

        /* Estilos para la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .descripcion {
            display: none; /* Oculta la descripción por defecto */
        }
    </style>
</head>
<body>
    <div class="topnav">
        <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="buscar_usuario.php">Mostrar Tabla</a></li>
            <li><a href="MostrarMapa.php">Mapa Conceptual</a></li>
            <li><a href="inicio.php">Cerrar Sesión</a></li>
        </ul>
    </div>

    <section id="destacados">
        <h2>Libros Destacados</h2>
        <div class="libro">
            <img src="harry_potter_OdF.png" alt="Libro 1">
            <h3>Harry Potter Orden del Fénix</h3>
            <button class="ver-mas">Ver Más</button>
            <p class="descripcion">La Orden del Fénix era una organización secreta fundada por Albus Dumbledore para oponerse y luchar contra Lord Voldemort y sus mortífagos.</p>
        </div>

        <div class="libro">
            <img src="Maze_Runner_CoM.png" alt="Libro 2">
            <h3>Maze Runner Correr o Morir</h3>
            <p class="descripcion">Un chico de 16 años despierta en un elevador sin memoria alguna de su identidad y pasado. Después de que llega a su destino, se encuentra con un grupo de chicos que habitan en un área rodeada de cuatro altos muros. Cada mes, un chico nuevo llega y con él, suministros.</p>
            <button class="ver-mas">Ver Más</button>
        </div>
        <div class="libro">
            <img src="Narnia_Sobrino_del_Mago.png" alt="Libro 2">
            <h3>Narnia Sobrino del Mago</h3>
            <p class="descripcion">Dos amigos, víctimas del poder de unos anillos mágicos, son arrojados a otro mundo en el que una malvada hechicera intenta convertirlos en sus esclavos. Pero entonces aparece Aslan y crea Narnia, un mundo poblado por seres mitológicos, animales parlantes y brujas malvadas.</p>
            <button class="ver-mas">Ver Más</button>
        </div>
        <div class="libro">
            <img src="Alas_de_Sangre.jpg" alt="Libro 2">
            <h3>Alas de Sangre</h3>
            <p class="descripcion">Alas de sangre, la primera entrega de la saga, introduce a los lectores en un mundo oscuro y complejo lleno de violencia, dragones, poderes. La acción se desarrolla en el Colegio de Guerra Basgiath, donde los cadetes buscan convertirse en jinetes y vincularse con un dragón.</p>
            <button class="ver-mas">Ver Más</button>
        </div>

        <div class = "bubbles"> 
            <span style="--i:11"></span>
            <span style="--i:12"></span>
            <span style="--i:24"></span>
            <span style="--i:10"></span>
            <span style="--i:14"></span>
            <span style="--i:23"></span>
            <span style="--i:18"></span>
            <span style="--i:16"></span>
            <span style="--i:19"></span>
            <span style="--i:20"></span>
            <span style="--i:22"></span>
            <span style="--i:25"></span>
            <span style="--i:18"></span>
            <span style="--i:21"></span>
            <span style="--i:15"></span>
            <span style="--i:13"></span>
            <span style="--i:26"></span>
            <span style="--i:17"></span>
            <span style="--i:13"></span>
            <span style="--i:11"></span>
        </div>
        
        <div class="libro 3">
            <img src="La_Sombra_del_Viento.png" alt="Libro 2">
            <h3>La Sombra del Viento</h3>
            <p class="descripcion">El pequeño Daniel Sempere es conducido por su padre a un misterioso lugar: El Cementerio de los Libros Olvidados. Allí descubrirá un libro maldito que le cambiará la vida y le llevará a descubrir unos caminos repletos de enigmas y secretos.</p>
            <button class="ver-mas">Ver Más</button>
        </div>

        <div class="libro 4">
            <img src="Cuento_de_Hadas.png" alt="Libro 2">
            <h3>Cuento de Hadas</h3>
            <p class="descripcion">Un cuento de hadas es una historia ficticia que puede contener personajes fantásticos —tales como hadas, duendes, elfos, brujas, sirenas, troles, gigantes, gnomos y animales parlantes así como encantamientos— normalmente representados en una secuencia inverosímil de eventos.</p>
            <button class="ver-mas">Ver Más</button>
        </div>

        <div class="libro 5">
            <img src="Historia_del_Tiempo.png" alt="Libro 2">
            <h3>Historia del Tiempo</h3>
            <p class="descripcion">Trata sobre la evolución que ha sufrido nuestro Universo; su pasado, presente y futuro. Usa el pensamiento científico para explicar el Big Bang, los agujeros negros, es decir el fin del universo. En fin que el autor con este libro nos explica sus conocimientos sobre la naturaleza del tiempo y del universo.</p>
            <button class="ver-mas">Ver Más</button>
        </div>

    </section>

    <script src="js/script.js"></script>
</body>
</html>

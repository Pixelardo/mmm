<?php
session_start();

if(isset($_POST['login'])) {
    include("con_db.php"); // Incluye el archivo de conexión a la base de datos

    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Consulta SQL para verificar las credenciales del administrador
    $consulta = "SELECT * FROM Administradores WHERE Correo_admin='$correo' AND Contraseña_admin='$contraseña'";
    $resultado = mysqli_query($conex, $consulta);

    if(mysqli_num_rows($resultado) > 0) {
        // El administrador existe, iniciar sesión
        $_SESSION['correo'] = $correo;
        header("Location: administrar_vendedores.php"); // Redireccionar al administrador al panel de administración
        exit();
    } else {
        ?>
                <h3 class="bad">¡Correo electrónico o contraseña incorrectos</h3>
                <?php
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Iniciar sesión como administrador</title>
</head>
<body>
    <h2>Iniciar sesión Administrador</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="correo">Correo electrónico:</label><br>
        <input type="email" id="correo" name="correo" required><br>
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        <input type="submit" name="login" value="Iniciar sesión">
    </form>
</body>
</html>

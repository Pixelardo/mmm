<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Vendedores</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2; /* Color de fondo */
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff; /* Color del contenedor */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Sombra */
        }
        h1 {
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        p {
            text-align: center;
            margin-bottom: 10px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff; /* Color del botón */
            color: #fff; /* Color del texto del botón */
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3; /* Cambia el color del botón al pasar el ratón */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Administración de Vendedores</h1>

        <!-- Botón para crear una nueva cuenta de vendedor -->
        <p><a class="btn" href="crear_cuenta_vendedor.php">Crear nueva cuenta de vendedor</a></p>

        <!-- Botón para modificar una cuenta de vendedor -->
        <p><a class="btn" href="modificar_cuenta_vendedor.php">Modificar cuenta de vendedor</a></p>

        <!-- Tabla para mostrar la lista de vendedores -->
        <table>
            <thead>
                <tr>
                    <th>ID Vendedor</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conectar a la base de datos
                include("con_db.php");

                // Consulta para obtener la lista de vendedores
                $consulta = "SELECT ID_Vendedor, Nombre, Email FROM vendedores";
                $resultado = mysqli_query($conex, $consulta);

                // Iterar sobre los resultados y mostrar cada vendedor en una fila de la tabla
                while($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>";
                    echo "<td>{$fila['ID_Vendedor']}</td>";
                    echo "<td>{$fila['Nombre']}</td>";
                    echo "<td>{$fila['Email']}</td>";
                    echo "<td><a href='eliminar_cuenta_vendedor.php?id={$fila['ID_Vendedor']}'>Eliminar</a></td>";
                    echo "</tr>";
                }

                // Liberar el resultado y cerrar la conexión
                mysqli_free_result($resultado);
                mysqli_close($conex);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

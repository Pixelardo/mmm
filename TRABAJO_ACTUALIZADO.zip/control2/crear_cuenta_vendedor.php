<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="css/estilo.css">
    <title>Crear Cuenta de Vendedor</title>
</head>
<body>
    <h1>Crear Cuenta de Vendedor</h1>
    
    <!-- Formulario para crear la cuenta del vendedor -->
    <form method="post" action="procesar_crear_cuenta.php">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br><br>
        
        <label for="email">Correo electrónico:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" required><br><br>
        
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        
        <input type="submit" value="Crear Cuenta">
    </form>
</body>
</html>

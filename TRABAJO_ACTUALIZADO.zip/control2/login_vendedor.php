<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Iniciar Sesión - Vendedor</title>
</head>
<body>
    <h1>Iniciar Sesión - Vendedor</h1>
    
    <!-- Formulario de inicio de sesión para vendedores -->
    <form method="post" action="procesar_login_vendedor.php">
        <label for="correo">Correo electrónico:</label><br>
        <input type="email" id="correo" name="correo" required><br><br>
        
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        
        <input type="submit" value="Iniciar Sesión">
    </form>
</body>
</html>

<?php
// Incluir archivo de conexión a la base de datos
include("con_db.php");

// Verificar si se enviaron los datos del formulario
if(isset($_POST['nombre'], $_POST['email'], $_POST['telefono'], $_POST['contraseña'])) {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $contraseña = $_POST['contraseña'];

    // Insertar la cuenta del vendedor en la base de datos
    $consulta = "INSERT INTO vendedores (Nombre, Email, Telefono, Contraseña, Fecha_Alta) VALUES ('$nombre', '$email', '$telefono', '$contraseña', CURRENT_DATE())";
    $resultado = mysqli_query($conex, $consulta);

    if($resultado) {
        echo "Cuenta de vendedor creada exitosamente.";
    } else {
        echo "Error al crear la cuenta de vendedor. Intente de nuevo.";
    }
} else {
    // Si no se enviaron los datos del formulario, redirigir de nuevo a la página de creación de cuenta
    header("Location: crear_cuenta_vendedor.php");
    exit();
}
?>

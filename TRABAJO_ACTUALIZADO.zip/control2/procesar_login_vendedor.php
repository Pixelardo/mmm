<?php
session_start(); // Iniciar sesión

if(isset($_POST['correo'], $_POST['contraseña'])) {
    // Obtener las credenciales del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Aquí debes realizar la validación de las credenciales en tu base de datos
    // Por ejemplo, una consulta SQL para verificar si el correo y la contraseña coinciden
    // Suponiendo que tienes una tabla 'vendedores' con campos 'Email' y 'Contraseña'
    // y que la conexión a la base de datos está configurada en 'con_db.php'
    include("con_db.php");
    $consulta = "SELECT ID_Vendedor FROM vendedores WHERE Email='$correo' AND Contraseña='$contraseña'";
    $resultado = mysqli_query($conex, $consulta);

    // Verificar si se encontró un vendedor con las credenciales proporcionadas
    if(mysqli_num_rows($resultado) == 1) {
        // Iniciar sesión y redirigir al vendedor a la página del vendedor
        $fila = mysqli_fetch_assoc($resultado);
        $_SESSION['id_vendedor'] = $fila['ID_Vendedor'];
        header("Location: pagina_vendedor.php");
        exit();
    } else {
        // Si las credenciales no son válidas, mostrar un mensaje de error y redirigir de nuevo a la página de inicio de sesión
        echo "Correo electrónico o contraseña incorrectos. Intente de nuevo.";
        header("refresh:3;url=login_vendedor.php"); // Redirigir después de 3 segundos
        exit();
    }
} else {
    // Si no se enviaron los datos del formulario, redirigir de nuevo a la página de inicio de sesión
    header("Location: login_vendedor.php");
    exit();
}
?>

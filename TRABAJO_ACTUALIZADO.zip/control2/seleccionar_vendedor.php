<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Vendedor</title>
</head>
<body>
    <h1>Seleccionar Vendedor</h1>
    <form action="modificar_cuenta_vendedor.php" method="GET">
        <label for="vendedor">Seleccione un vendedor:</label>
        <select name="id_vendedor" id="vendedor">
            <?php
            include("con_db.php");
            $consulta = "SELECT ID_Vendedor, Nombre FROM vendedores";
            $resultado = mysqli_query($conex, $consulta);
            while($fila = mysqli_fetch_assoc($resultado)) {
                echo "<option value='{$fila['ID_Vendedor']}'>{$fila['Nombre']}</option>";
            }
            mysqli_close($conex);
            ?>
        </select>
        <button type="submit">Modificar</button>
    </form>
</body>
</html>

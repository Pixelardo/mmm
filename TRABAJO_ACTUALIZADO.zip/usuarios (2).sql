-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-04-2024 a las 23:28:50
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `usuarios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administradores`
--

CREATE TABLE `administradores` (
  `ID_Administrador` int(11) NOT NULL,
  `Nombre_Administrador` varchar(100) DEFAULT NULL,
  `Contacto_Administrador` varchar(20) DEFAULT NULL,
  `Correo_admin` varchar(255) DEFAULT NULL,
  `Contraseña_admin` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administradores`
--

INSERT INTO `administradores` (`ID_Administrador`, `Nombre_Administrador`, `Contacto_Administrador`, `Correo_admin`, `Contraseña_admin`) VALUES
(1, 'Juan Pérez', '123456789', 'juan@example.com', 'password123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `ID_Libro` int(11) NOT NULL,
  `ISBN` varchar(13) DEFAULT NULL,
  `Titulo` varchar(255) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Fecha_Alta` date DEFAULT NULL,
  `Genero` varchar(50) DEFAULT NULL,
  `Precio` decimal(10,2) DEFAULT NULL,
  `Formato` varchar(20) DEFAULT NULL,
  `Autor` varchar(255) DEFAULT NULL,
  `Idioma` varchar(50) DEFAULT NULL,
  `Disponibilidad` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`ID_Libro`, `ISBN`, `Titulo`, `Descripcion`, `Fecha_Alta`, `Genero`, `Precio`, `Formato`, `Autor`, `Idioma`, `Disponibilidad`) VALUES
(1, '9780545010221', 'Harry Potter y las Reliquias de la Muerte', 'La novela final de la serie de Harry Potter', '2024-04-20', 'Fantasía', 10.99, 'Tapa dura', 'J.K. Rowling', 'Español', 1),
(2, '12312312', 'eq', 'asads', '2024-04-12', 'sss', 123123.00, 'sdfsf', 'qweqwe', 'eeee', 0),
(6, '987897687678', 'hbbjkbkb', 'yghjiuybig8', '2024-04-25', 'JBKBKJK', 34789.00, 'HGJJBJB', 'YO', 'MMM', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `contraseña` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `nombre`, `email`, `fecha_creacion`, `contraseña`) VALUES
(2, 'ww', '', '', '2024-04-20 18:16:55', '123'),
(3, 'franciscomar', '', 'fran@dd.com', '2024-04-21 00:22:39', '123'),
(4, 'rfasad', '', 'aaaa@ww.com', '2024-04-21 00:25:15', '123'),
(5, 'rfasadss', '', 'aaaa@ww.com', '2024-04-20 18:26:37', '123'),
(6, 'IceSword14', 'asda', 'francismch123@gmail.com', '2024-04-20 18:28:43', '123'),
(7, 'Diegolin', 'diego', 'diego123@gmail.com', '2024-04-20 18:33:52', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedores`
--

CREATE TABLE `vendedores` (
  `ID_Vendedor` int(11) NOT NULL,
  `Nombre` varchar(100) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Contraseña` varchar(255) NOT NULL,
  `Telefono` varchar(20) DEFAULT NULL,
  `Fecha_Alta` date DEFAULT NULL,
  `Total_Ventas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vendedores`
--

INSERT INTO `vendedores` (`ID_Vendedor`, `Nombre`, `Email`, `Contraseña`, `Telefono`, `Fecha_Alta`, `Total_Ventas`) VALUES
(0, 'francisco', 'sad@gmail.com', 'lknk', '89789', '2024-04-21', NULL),
(2, 'María', 'maria@example.com', 'password123', '987654321', '2024-04-21', 45),
(3, 'Pedro', 'pedro@example.com', 'password12', '555666777', '2024-04-22', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`ID_Administrador`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ID_Libro`),
  ADD UNIQUE KEY `ISBN` (`ISBN`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `vendedores`
--
ALTER TABLE `vendedores`
  ADD PRIMARY KEY (`ID_Vendedor`),
  ADD KEY `ID_Vendedor` (`ID_Vendedor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `ID_Libro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
